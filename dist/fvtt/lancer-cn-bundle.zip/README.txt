LANCER 中文（简易车卡器）测试包
================================

包内文件
--------
modules/lancer-cn/          界面中文模组（整个文件夹放进 Foundry 的 Data/modules/）
lcp/lancer-cn-core.lcp      核心规则书中文内容包
lcp/lancer-cn-expansions.lcp 扩展内容中文内容包

需要：Foundry VTT v13，LANCER 系统 v3.1.3 或更高。

一、安装模组
------------
把 modules/lancer-cn 整个文件夹复制到 Foundry 用户数据的 Data/modules/ 下，得到：
    Data/modules/lancer-cn/module.json
  - 本机：%LOCALAPPDATA%\FoundryVTT\Data\modules\
  - 自建服务器：服务器的 Data/modules/（用 FTP / 面板文件管理器上传）
文件夹名必须是 lancer-cn。复制后重启 Foundry（或回到设置页刷新），在「附加模组」列表里能看到「LANCER 中文」。

二、在世界中启用
----------------
1. 进入 LANCER 世界 → 游戏设置 → 管理模组 → 勾选「LANCER 中文」→ 保存。
2. 游戏设置 → 配置设置 → 核心 → 语言，选「中文」→ 保存并刷新。
   （想要 Foundry 核心界面也是中文，另装 foundry_chn 模组，它同样用「中文」。）

三、导入内容包（GM）
--------------------
打开侧栏「合集包」标签 → 点「LANCER 内容包管理器」（LANCER Compendium Manager）：
1. 先更新 / 建立核心数据（Update / Rebuild Core Data）。
2. 在官方内容里勾选要用的补充书（Long Rim、Wallflower、KTB 等）→ 导入／更新所选。
3. 「从文件导入」选 lcp/lancer-cn-core.lcp → 导入内容包。
4. 再选 lcp/lancer-cn-expansions.lcp → 导入内容包。
顺序很重要：中文包要在英文数据之后导入，才会覆盖成中文。

四、导入车卡器资料（GM）
------------------------
游戏设置 → 配置设置 → 模组设置 → LANCER 中文 → 「导入车卡器资料」→ 确认。
会建立 21 张专业牌照、把骨架牌照改成中文名，并生成「车卡器资料」日志合集包。
可以重复运行。

检查与反馈
----------
- 打开一个机甲 / NPC 表、发起一次攻击和伤害、看看状态图标与扫描卡，确认文字是中文。
- 按 F12 打开控制台，若有红色报错（尤其含 lancer-cn 的），截图发给车卡器维护者。
- 仍看到英文的地方，也请截图说明在哪个界面。
